<?php $__env->startSection('body'); ?>

    <div class="main_content">
        <div class="container">
            <div class="col-md-10 offset-md-1 col-lg-10 offset-lg-1">
                <div class="home_page_product">
                    <?php if($posts->count() > 0): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product_single view_product_details" data-post="<?php echo e($post->id); ?>">
                                <img src="/post/images/thumb/<?php echo e($post->fistImage()); ?>">
                                <div class="product_single_shadow">
                                    <p><i class="fas fa-eye"></i><?php echo e($post->clicks); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div id="outputModal"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script defer>
        $(document).ready(function () {
            $(document).on('click', '.view_product_details', function () {
                let item = $(this);
                let post = item.data('post');
                $.get(`/post/${post}/details`, function (data, status) {
                    $("#outputModal").html(data);
                    $("#product_overview_modal").modal('show');
                    var owl = $(".owl-carousel");
                    owl.owlCarousel({
                        items: 1,
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fiverr\nosmercado\resources\views/site/index.blade.php ENDPATH**/ ?>