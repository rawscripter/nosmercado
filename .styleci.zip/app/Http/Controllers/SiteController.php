<?php

namespace App\Http\Controllers;

use App\Category;
use App\Post;
use Carbon\Carbon;
use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function index()
    {
        $categories = Category::orderBy('id', 'asc')->get();
        $posts = Post::where('expire_date', '>=', Carbon::now())->get();
        $posts = $posts->shuffle();
        return view('site.index', compact('posts', 'categories'));
    }

    public function categoryProducts($category)
    {
        $categories = Category::orderBy('id', 'asc')->get();
        $category = Category::whereName($category)->first();
        $posts = $category->posts->shuffle();
        return view('site.index', compact('posts', 'categories'));
    }


}
