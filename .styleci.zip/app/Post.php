<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = [
        'category_id',
        'subcategory_id',
        'title',
        'price',
        'email',
        'description',
        'active',
        'expire_date',
        'clicks'
    ];

    public function images()
    {
        return $this->belongsToMany(Image::class, 'post_images');
    }

    public function fistImage()
    {
        $images = $this->images;
        return $images[0]->name;
    }


}
